/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.twitter4jtesting;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.*;
import java.io.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author kamil
 */
public class testing {
       public static void main(String[] args) throws IOException 
    { 
  
           try {
               // The cursor will remain
               // just after the 1
               System.out.print("GfG1");
               
           
               // The factory instance is re-useable and thread safe.
               ConfigurationBuilder cb = new ConfigurationBuilder();
               cb.setDebugEnabled(true)
                .setOAuthConsumerKey("Lyxd00oKyOJFZ4FxqiKkJUBwG")
                .setOAuthConsumerSecret("RA8J3wYdj1XKB5NrZQ4ny5vhfs2YHIdgrPcDIP8RXrQsaK31yc")
                .setOAuthAccessToken("4141536579-QYXCOhe4vw3ciWLkaqHYxeRk1OhHX3Z0MfBNbFs")
                .setOAuthAccessTokenSecret("9VyHq0MIYAUE8taqStT9ZMiPfHbOdXGkfbps5oHJT2smK");
                TwitterFactory tf = new TwitterFactory(cb.build());
                Twitter twitter = tf.getInstance();
           
                List<Status> statuses = twitter.getHomeTimeline();
                // just testing
                /*for (Status status : statuses) {
                    //System.out.println(status.getUser().getName() + ":" + status.getText());
                }*/
                    
                // Key word search on tweets
                System.out.println( "Example 2") ; 
                Query query = new Query("first solar"); // Look for exact match syntax on twitter docs
                query.setCount(10); //tweet count limit
                query.setLang( "en");
                QueryResult result = twitter.search(query);
                FileWriter csvWriter = new FileWriter("D:/NYU/Semester 2/Big Data Science/Project Idea/Final Project/new2.csv"); // change to relative path later
                csvWriter.append("ScreeName");
                csvWriter.append(",");
                csvWriter.append("TweetText");
                csvWriter.append("\n");
                for (Status st : result.getTweets()) {
                //System.out.println("@" + st.getUser().getScreenName() + ":" + st.getText());
                //List<String[]> dataLines = new ArrayList<>();
                //dataLines.add(new String[]{ st.getUser().getScreenName(),  st.getText() });
                //System.out.println("Data Lines\t" + dataLines.get(0));
                csvWriter.append( st.getUser().getScreenName());
                csvWriter.append(",");
                System.out.println(st.getText().replace("\n", "").replace("\r", "").replace(",", " "));
                csvWriter.append( st.getText().replace("\n", "").replace("\r", "").replace(",", " "));
                csvWriter.append("\n");
                System.out.println("Written");
    }//For ends 
                csvWriter.flush();
                
                csvWriter.close();
    
           
               


// Testing Jsoup 
/*
    Document doc = Jsoup.connect("https://www.codetriage.com/?language=Java").get();

                // With the document fetched, we use JSoup's title() method to fetch the title
     System.out.printf("Title: %s\n", doc.title());
     Elements repositories = doc.getElementsByClass("repo-item");
*/
      /**
       * For each repository, extract the following information:
       * 1. Title
       * 2. Number of issues
       * 3. Description
       * 4. Full name on github
       */
     /* for (Element repository : repositories) {
        // Extract the title
        String repositoryTitle = repository.getElementsByClass("repo-item-title").text();

        // Extract the number of issues on the repository
        String repositoryIssues = repository.getElementsByClass("repo-item-issues").text();

        // Extract the description of the repository
        String repositoryDescription = repository.getElementsByClass("repo-item-description").text();

        // Get the full name of the repository
        String repositoryGithubName = repository.getElementsByClass("repo-item-full-name").text();

        // The reposiory full name contains brackets that we remove first before generating the valid Github link.
        String repositoryGithubLink = "https://github.com/" + repositoryGithubName.replaceAll("[()]", "");

        // Format and print the information to the console
        System.out.println(repositoryTitle + " - " + repositoryIssues);
        System.out.println("\t" + repositoryDescription);
        System.out.println("\t" + repositoryGithubLink);
        System.out.println("\n");

      }*/
      
      
      /*
      
     Document doc2 = Jsoup.connect("https://www.google.com/search?as_q=&as_epq=%FSLR").userAgent("Mozilla").ignoreHttpErrors(true).timeout(0).get();
     System.out.println(doc2.title());
     Elements links2 = doc2.select("h3.r a");
     System.out.println(links2);
        for (Element link : links2) {
             System.out.println(doc2.title());
        
        }*/

  
           } catch (TwitterException ex) {
               Logger.getLogger(testing.class.getName()).log(Level.SEVERE, null, ex);
           }
    
    }
    
}
